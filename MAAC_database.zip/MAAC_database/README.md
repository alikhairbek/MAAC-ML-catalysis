# MAAC-DB: A DFT Database of Metal-Catalyzed Azide–Alkyne Cycloaddition

A curated, internally consistent density-functional-theory (DFT) database of homogeneous
metal-catalyzed azide–alkyne cycloaddition (MAAC / "click") reactions, assembled from
published computational studies. It provides optimized geometries, energetics, electronic
descriptors, and mechanism-resolved activation barriers across **five catalytic metals**,
under a **single level of theory** — filling a recognized gap (large consistent datasets exist
for *heterogeneous* catalysis, but not for *homogeneous* organometallic catalysis).

---

## 1. Scope and contents

| Entity | Count |
|---|---|
| Optimized structures (with geometries) | 847 |
| Mechanism-resolved activation barriers | 127 |
| Catalytic systems (metal × ligand × nuclearity) | 128 |
| Source studies | 12 |
| Metals | Cu, Ag, Au, Ru, Rh |
| Ligand families | NHC, halogenated NHC, NHSi/NHGe, Cu–halide, phosphine, N,N-donors, Cp*/Cp-X, polynuclear NHC |
| Catalytic-cycle roles | acetylide, reactant complex (RC), TS1, intermediate (IC), TS2, product (P), free azide/alkyne, catalyst |
| Pathways | 1,4- and 1,5-triazole regiochemistry |
| Solvents | gas, toluene, water, THF, methanol, acetonitrile (implicit, CPCM) |

**Level of theory (uniform across the database):**
MN12-L / def2-SVP (def2-TZVP for transition metals), CPCM implicit solvation, Gaussian 16.

---

## 2. Files

```
MAAC_database/
├── MAAC_catalysis.sqlite     # relational database (4 linked tables)
├── structures.csv            # one row per optimized structure
├── barriers.csv              # one row per elementary activation barrier
├── systems.csv               # one row per catalytic system
├── papers.csv                # provenance (source studies)
├── MAAC_database.json        # full database as nested JSON
├── schema.sql                # SQL schema (table definitions)
├── geometries/               # XYZ geometry library, one file per structure
│   └── MAAC-00001.xyz ...
└── README.md                 # this file
```

---

## 3. Schema

**`structures`** — every optimized stationary point
`structure_id` (PK) · `paper_code` · `system_id` · `metal` · `ligand` · `nuclearity` (mono/bi) ·
`role` · `step` (1/2 for TSs) · `pathway` (1,4 / 1,5) · `solvent` · `charge` · `mult` ·
`natom` · `formula` · `E_scf` · `H` · `G` (free energy, Hartree) ·
`HOMO` `LUMO` `gap` `mu` `eta` `omega` `chi` `dNmax` (eV; Koopmans-based reactivity descriptors) ·
`n_imag` (imaginary frequencies) · `is_ts` · `is_minimum` · `level_of_theory` · `xyz_file` · `original_log` ·
`pct_Vbur` (% buried volume around the metal, steric) · `q_metal` (Mulliken charge on the metal) ·
`smiles` · `inchi` (geometry-perceived chemical identifiers)

**`barriers`** — mechanism-resolved elementary activation free energies
`barrier_id` (PK) · `system_id` · `pathway` · `step` ·
`reactant_id` → structures · `ts_id` → structures · `product_id` → structures ·
`dG_act_kcal` · `dG_rxn_kcal` · `ref_role`

**`systems`** — `system_id` (PK) · `paper_code` · `metal` · `ligand` · `nuclearity` · `n` (structures)

**`papers`** — `paper_code` (PK) · `paper_name` · `journal` · `level_of_theory` · `n_structures` · `doi`

---

## 4. How activation barriers are defined

Barriers follow the catalytic cycle **RC → TS1 → IC → TS2 → P**. Rather than collapsing each system
to a single value, two *elementary* free-energy barriers are stored, each referenced to the
preceding minimum of identical molecular formula (ensuring a physically valid difference):

- **Step 1:** ΔG‡₁ = G(TS1) − G(RC)
- **Step 2:** ΔG‡₂ = G(TS2) − G(IC)

All free energies are at the level of theory above. Computed barriers reproduce the values and
regioselectivity reported in the source studies (e.g., 1,5-selectivity for Ru/Rh; Cu being the
lowest-barrier metal), validating the extraction.

---

## 5. Controlled vocabularies

- **role**: `acetylide`, `RC`, `TS`, `IC`, `product`, `azide`, `alkyne`, `catalyst`, `other`
- **nuclearity**: `mono` (one metal center), `bi` (two)
- **pathway**: `1,4`, `1,5`, `na`
- **is_ts / is_minimum**: derived from imaginary-frequency count (TS = exactly 1; minimum = 0)

---

## 6. Usage

**SQLite (recommended):**
```python
import sqlite3, pandas as pd
con = sqlite3.connect("MAAC_catalysis.sqlite")
# mean barrier per metal
pd.read_sql("SELECT metal, COUNT(*) n, ROUND(AVG(dG_act_kcal),1) mean_dG FROM barriers GROUP BY metal", con)
# join a barrier to its TS geometry file
pd.read_sql("SELECT b.barrier_id,b.dG_act_kcal,s.xyz_file FROM barriers b JOIN structures s ON b.ts_id=s.structure_id", con)
```
**CSV / pandas:** load `structures.csv`, `barriers.csv` directly.
**Geometries:** every `structures.xyz_file` points to a standard XYZ file under `geometries/`.

---

## 7. Limitations and notes

- Barriers are intrinsic (within-complex) elementary-step free energies; absolute values depend on
  the chosen reference state and the MN12-L level.
- A small number of structures appear at several implicit-solvent single points; each is a distinct row.
- The metal × ligand space is partly **confounded** (each ligand family was studied mainly for one metal),
  which limits extrapolation of any model trained on this data to entirely new ligand classes.
- Every record carries its source-study **`doi`** (in `papers.csv` and as a `doi` column in
  `structures.csv`, `barriers.csv`, `systems.csv`), so any subset remains traceable to its origin.
- **Charges are Mulliken** (`q_metal`): the source logs do not contain NBO/Natural Population Analysis,
  so NBO charges would require re-running Gaussian with `pop=nbo`. Mulliken is provided as the available analysis.
- **`smiles`/`inchi` are perceived from geometry** (OpenBabel); for organometallic complexes bond perception is
  approximate and InChI conventionally disconnects the metal. They are intended as interoperability handles, not exact bonding.
- **`pct_Vbur`** is computed with a 3.5 Å sphere around the first metal center (morfeus defaults); for binuclear
  systems it refers to that first center.

---

## 8. License and citation

Suggested release: deposit on Zenodo/Figshare under **CC-BY 4.0** to obtain a citable DOI.
Please cite the original studies (`papers.csv`) alongside the database.

**Version:** 1.1 (adds a twelfth source study — Cu–halide MAAC, *Appl. Organomet. Chem.*)  ·  **Generator:** `database_build.py` (reproducible from the source Gaussian logs).

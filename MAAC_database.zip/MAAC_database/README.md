# MAAC-DB: A DFT Database of Metal-Catalyzed Azide–Alkyne Cycloaddition

A curated, internally consistent density-functional-theory (DFT) database of homogeneous
metal-catalyzed azide–alkyne cycloaddition (MAAC / "click") reactions, assembled from
published computational studies. It provides optimized geometries, energetics, electronic
descriptors, and mechanism-resolved activation barriers across **five catalytic metals**,
under a **single level of theory** — filling a recognized gap (large consistent datasets exist
for *heterogeneous* catalysis, but not for *homogeneous* organometallic catalysis).

---

## 1. Scope and contents

| Entity | Count |
|---|---|
| Optimized structures (with geometries) | 750 (37 duplicate files and 60 structures of unpublished systems of earlier versions removed) |
| Mechanism-resolved activation barriers | 91 (same environment, frequencies, TS geometry and imaginary mode verified, each stationary point used once; 16 excluded candidates listed in barriers_excluded.csv) |
| Catalytic systems (metal × ligand × nuclearity) | 118 (every system is part of a published study; the 9 unpublished systems of the ref. 19 archive are listed in removed_unpublished.csv) |
| Source studies | 12 |
| Metals | Cu, Ag, Au, Ru, Rh |
| Ligand families | phosphines, CX₂-bridged bis(α-diimine) (dicopper Com-X), diimines, phosphite, thioether, nitrile, ADAP diazaphospholene, Cp*/Cp, halogenated NHC, pentasubstituted cyclopentadienyl, IMe, pyridine-functionalized NHC, NHC-stabilized silylene/germylene, bipyridine/phenanthroline/bis(oxazoline) |
| Catalytic-cycle roles | acetylide (Cu, Ag, Au) or alkyne complex (π-bound intact alkyne: Ru, Rh and the π-complexes of refs. 22, 27), reactant complex (RC), TS1, intermediate (IC), TS2, product (P), free azide/alkyne, catalyst |
| Pathways | 1,4- and 1,5-triazole regiochemistry |
| Environments | gas phase (414 structures) or C-PCM: toluene, water, THF, methanol, acetonitrile (396; 261 of them single points) |

**Level of theory:** MN12-L / def2-SVP (def2-TZVP for transition metals), Gaussian 16, uniform across the database. **Solvation is not uniform**: each structure records `phase` (gas / cpcm), `solvent`, `eps` and `calc_type` (opt+freq / single-point). Version 14 — see the repository README for the changelog.

---

## 2. Files

```
MAAC_database/
├── MAAC_catalysis.sqlite     # relational database (8 linked tables)
├── structures.csv            # one row per optimized structure
├── barriers.csv              # one row per elementary activation barrier (91, verified)
├── barriers_excluded.csv     # the 16 excluded candidate barriers with reasons
├── ts_verification.csv       # geometric and normal-mode verification of every barrier
├── duplicates_removed.csv    # the 37 duplicate files removed in v14
├── removed_unpublished.csv   # the 9 unpublished systems of the ref. 19 archive removed in v15
├── systems.csv               # one row per catalytic system
├── papers.csv                # provenance (source studies)
├── MAAC_database.json        # full database as nested JSON
├── schema.sql                # SQL schema (table definitions)
├── geometries/               # XYZ geometry library, one file per structure
│   └── MAAC-00001.xyz ...
└── README.md                 # this file
```

---

## 3. Schema

**`structures`** — every optimized stationary point
`structure_id` (PK) · `paper_code` · `system_id` · `metal` · `ligand` · `nuclearity` (mono/bi) ·
`role` · `step` (1/2 for TSs) · `pathway` (1,4 / 1,5) · `phase` · `solvent` · `eps` · `calc_type` · `charge` · `mult` ·
`natom` · `formula` · `E_scf` · `H` · `G` (free energy, Hartree) ·
`HOMO` `LUMO` `gap` `mu` `eta` `omega` `chi` `dNmax` (eV; Koopmans-based reactivity descriptors) ·
`n_imag` · `imag_freq_cm` (value of the imaginary frequency) · `is_ts` · `is_minimum` · `level_of_theory` · `xyz_file` · `original_log` · `si_label` · `si_match_dev_A` (label and geometric deviation of the same structure in the Supporting Information of the source study, where matched) ·
`pct_Vbur` (% buried volume around the metal, mean over the metal centres) · `q_metal` (Mulliken charge on the metal, mean over the metal centres) · `pct_Vbur_v13_first_atom` · `q_metal_v13_first_atom` (the first-atom values of v13) ·
`smiles` · `inchi` (geometry-perceived chemical identifiers)

**`barriers`** — mechanism-resolved elementary activation free energies
`barrier_id` (PK) · `system_id` · `pathway` · `step` ·
`reactant_id` → structures · `ts_id` → structures · `product_id` → structures ·
`dG_act_kcal` · `dG_step_rxn_kcal` · `dG_to_product_kcal` · `ref_role` · `phase` · `solvent` · `eps` · `charge` · `imag_freq_cm` ·
`forming_pair` · `forming_CN_A` · `formed_CN_A` · `cn_stretch_share` · `mode_ratio_to_largest_pair` (transition-state verification; see ts_verification for the atom indices and the verdict)

**`systems`** — `system_id` (PK) · `paper_code` · `metal` · `ligand` · `nuclearity` · `n` (structures) · `catalyst_description` · `ligand_family` · `substrates` · `environments` · `n_barriers` · `ref_in_paper`

**`removed_unpublished`** — `system_id` · `paper_code` · `metal` · `ligand` · `nuclearity` · `n_structures` · `n_barriers_modelling_set` · `description` · `n_candidate_barriers` · `reason`

**`ts_verification`** — one row per barrier: `imag_freq_cm` · `n_formed` · `formed_pair` · `formed_CN_A` · `forming_pair` · `forming_CN_A` · `cn_stretch_share` (|Δr| of the forming N···C pair in the Gaussian-normalized imaginary mode) · `cn_dr` · `max_other_dr` · `other_pair` · `ratio` · `largest_disp_atom` · `verdict` · `accepted`

**`duplicates_removed`** — `removed_id` · `kept_id` · `system_removed` · `system_kept` · `role` · `log_removed` · `log_kept`

**`papers`** — `paper_code` (PK) · `paper_name` · `journal` · `level_of_theory` · `n_structures` · `doi`

---

## 4. How activation barriers are defined

Barriers follow the catalytic cycle **RC → TS1 → IC → TS2 → P**. Rather than collapsing each system
to a single value, two *elementary* free-energy barriers are stored, each referenced to the
preceding minimum of identical molecular formula (ensuring a physically valid difference):

- **Step 1:** ΔG‡₁ = G(TS1) − G(RC)
- **Step 2:** ΔG‡₂ = G(TS2) − G(IC)

All free energies are at the level of theory above. Computed barriers reproduce the values and
regioselectivity reported in the source studies (1,4-triazoles with the coinage metals, 1,5-selectivity for Ru/Rh). Where a study computed both regiochemical channels, each TS is referenced to the precursor of its own channel.

---

## 5. Controlled vocabularies

- **role**: `acetylide`, `alkyne complex`, `RC`, `TS`, `IC`, `product`, `azide`, `alkyne`, `catalyst`, `other`
- **nuclearity**: `mono` (one metal center), `bi` (two)
- **pathway**: `1,4`, `1,5`, `na`
- **is_ts / is_minimum**: derived from imaginary-frequency count (TS = exactly 1; minimum = 0)

---

## 6. Usage

**SQLite (recommended):**
```python
import sqlite3, pandas as pd
con = sqlite3.connect("MAAC_catalysis.sqlite")
# mean barrier per metal
pd.read_sql("SELECT metal, COUNT(*) n, ROUND(AVG(dG_act_kcal),1) mean_dG FROM barriers GROUP BY metal", con)
# join a barrier to its TS geometry file
pd.read_sql("SELECT b.barrier_id,b.dG_act_kcal,s.xyz_file FROM barriers b JOIN structures s ON b.ts_id=s.structure_id", con)
```
**CSV / pandas:** load `structures.csv`, `barriers.csv` directly.
**Geometries:** every `structures.xyz_file` points to a standard XYZ file under `geometries/`.

---

## 7. Limitations and notes

- Barriers are intrinsic (within-complex) elementary-step free energies; absolute values depend on
  the chosen reference state and the MN12-L level.
- Every stationary point enters once (v14 de-duplication); single-point C-PCM energies on gas-phase geometries are distinct rows with `calc_type = single-point` and no free energy.
- The metal × ligand space is partly **confounded** (each ligand family was studied mainly for one metal),
  which limits extrapolation of any model trained on this data to entirely new ligand classes.
- Every record carries its source-study **`doi`** (in `papers.csv` and as a `doi` column in
  `structures.csv`, `barriers.csv`, `systems.csv`), so any subset remains traceable to its origin.
- **Charges are Mulliken** (`q_metal`): the source logs do not contain NBO/Natural Population Analysis,
  so NBO charges would require re-running Gaussian with `pop=nbo`. Mulliken is provided as the available analysis.
- **`smiles`/`inchi` are perceived from geometry** (OpenBabel); for organometallic complexes bond perception is
  approximate and InChI conventionally disconnects the metal. They are intended as interoperability handles, not exact bonding.
- **`pct_Vbur`** is computed with a 3.5 Å sphere around each metal center (morfeus defaults) and averaged over the metal centres of dinuclear species (v14; v13 used the first metal atom of the input).

---

## 8. License and citation

Suggested release: deposit on Zenodo/Figshare under **CC-BY 4.0** to obtain a citable DOI.
Please cite the original studies (`papers.csv`) alongside the database.

**Version:** 15 (October 2026)  ·  **Generators:** the authors' processing scripts (log parsing, de-duplication, nuclearity and channel assignment, transition-state verification from the imaginary normal mode, removal of the unpublished ref. 19 systems, `alkyne complex` role labels), applied to the source Gaussian outputs; not distributed.

-- papers
CREATE TABLE "papers" (
"paper_code" TEXT,
  "paper_name" TEXT,
  "journal" TEXT,
  "level_of_theory" TEXT,
  "n_structures" INTEGER,
  "doi" TEXT,
  "ref_in_paper" INTEGER,
  "catalyst_description" TEXT,
  "substrates" TEXT,
  "functional_basis" TEXT,
  "environments_structures" TEXT,
  "environments_barriers" TEXT,
  "charge_states" TEXT,
  "n_opt_freq" INTEGER,
  "n_single_point" INTEGER,
  "n_barriers" INTEGER
);

-- systems
CREATE TABLE "systems" (
"system_id" TEXT,
  "paper_code" TEXT,
  "metal" TEXT,
  "ligand" TEXT,
  "nuclearity" TEXT,
  "n" INTEGER,
  "doi" TEXT,
  "ligand_family" TEXT,
  "catalyst_description" TEXT,
  "substrates" TEXT,
  "environments" TEXT,
  "n_barriers" INTEGER,
  "ref_in_paper" REAL
);

-- structures
CREATE TABLE "structures" (
"structure_id" TEXT,
  "paper_code" TEXT,
  "system_id" TEXT,
  "metal" TEXT,
  "ligand" TEXT,
  "nuclearity" TEXT,
  "role" TEXT,
  "step" REAL,
  "pathway" TEXT,
  "phase" TEXT,
  "solvent" TEXT,
  "eps" REAL,
  "calc_type" TEXT,
  "charge" INTEGER,
  "mult" INTEGER,
  "natom" INTEGER,
  "formula" TEXT,
  "E_scf" REAL,
  "H" REAL,
  "G" REAL,
  "HOMO" REAL,
  "LUMO" REAL,
  "gap" REAL,
  "mu" REAL,
  "eta" REAL,
  "omega" REAL,
  "chi" REAL,
  "dNmax" REAL,
  "n_imag" REAL,
  "imag_freq_cm" REAL,
  "is_ts" INTEGER,
  "is_minimum" INTEGER,
  "level_of_theory" TEXT,
  "xyz_file" TEXT,
  "original_log" TEXT,
  "pct_Vbur" REAL,
  "q_metal" REAL,
  "smiles" TEXT,
  "inchi" TEXT,
  "si_label" TEXT,
  "si_match_dev_A" REAL,
  "doi" TEXT,
  "q_metal_v13_first_atom" REAL,
  "pct_Vbur_v13_first_atom" REAL
);

-- barriers
CREATE TABLE "barriers" (
"barrier_id" TEXT,
  "system_id" TEXT,
  "paper_code" TEXT,
  "metal" TEXT,
  "nuclearity" TEXT,
  "pathway" TEXT,
  "step" INTEGER,
  "reactant_id" TEXT,
  "ts_id" TEXT,
  "product_id" TEXT,
  "ref_role" TEXT,
  "phase" TEXT,
  "solvent" TEXT,
  "eps" REAL,
  "charge" INTEGER,
  "dG_act_kcal" REAL,
  "dG_step_rxn_kcal" REAL,
  "dG_to_product_kcal" REAL,
  "imag_freq_cm" REAL,
  "forming_pair" TEXT,
  "forming_CN_A" REAL,
  "formed_CN_A" REAL,
  "cn_stretch_share" REAL,
  "mode_ratio_to_largest_pair" REAL,
  "doi" TEXT
);

-- barriers_excluded
CREATE TABLE "barriers_excluded" (
"barrier_id" TEXT,
  "system_id" TEXT,
  "paper_code" TEXT,
  "metal" TEXT,
  "step" INTEGER,
  "reactant_id" TEXT,
  "ts_id" TEXT,
  "dG_act_kcal_v12" REAL,
  "reason" TEXT
);

-- ts_verification
CREATE TABLE "ts_verification" (
"barrier_id" TEXT,
  "ts_id" TEXT,
  "system_id" TEXT,
  "metal" TEXT,
  "step" INTEGER,
  "pathway" TEXT,
  "imag_freq_cm" REAL,
  "n_formed" INTEGER,
  "formed_pair" TEXT,
  "formed_CN_A" REAL,
  "forming_pair" TEXT,
  "forming_CN_A" REAL,
  "cn_stretch_share" REAL,
  "cn_dr" REAL,
  "max_other_dr" REAL,
  "other_pair" TEXT,
  "ratio" REAL,
  "largest_disp_atom" TEXT,
  "verdict" TEXT,
  "accepted" INTEGER
);

-- duplicates_removed
CREATE TABLE "duplicates_removed" (
"removed_id" TEXT,
  "kept_id" TEXT,
  "system_removed" TEXT,
  "system_kept" TEXT,
  "role" TEXT,
  "log_removed" TEXT,
  "log_kept" TEXT
);

-- removed_unpublished
CREATE TABLE "removed_unpublished" (
"system_id" TEXT,
  "paper_code" TEXT,
  "metal" TEXT,
  "ligand" TEXT,
  "nuclearity" TEXT,
  "n_structures" INTEGER,
  "n_barriers_modelling_set" INTEGER,
  "description" TEXT,
  "n_candidate_barriers" INTEGER,
  "reason" TEXT
);


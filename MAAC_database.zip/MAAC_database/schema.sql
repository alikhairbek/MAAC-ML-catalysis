CREATE TABLE papers(paper_code TEXT PRIMARY KEY, paper_name TEXT, journal TEXT, level_of_theory TEXT, n_structures INT, doi TEXT);

CREATE TABLE systems(system_id TEXT PRIMARY KEY, paper_code TEXT, metal TEXT, ligand TEXT, nuclearity TEXT, n INT,
        FOREIGN KEY(paper_code) REFERENCES papers(paper_code));

CREATE TABLE structures(structure_id TEXT PRIMARY KEY, paper_code TEXT, system_id TEXT, metal TEXT, ligand TEXT,
        nuclearity TEXT, role TEXT, step INT, pathway TEXT, solvent TEXT, charge INT, mult INT, natom INT, formula TEXT,
        E_scf REAL, H REAL, G REAL, HOMO REAL, LUMO REAL, gap REAL, mu REAL, eta REAL, omega REAL, chi REAL, dNmax REAL,
        n_imag INT, is_ts INT, is_minimum INT, level_of_theory TEXT, xyz_file TEXT, original_log TEXT,
        FOREIGN KEY(system_id) REFERENCES systems(system_id));

CREATE TABLE barriers(barrier_id TEXT PRIMARY KEY, system_id TEXT, paper_code TEXT, metal TEXT, nuclearity TEXT,
        pathway TEXT, step INT, reactant_id TEXT, ts_id TEXT, product_id TEXT, dG_act_kcal REAL, dG_rxn_kcal REAL, ref_role TEXT,
        FOREIGN KEY(ts_id) REFERENCES structures(structure_id));

